# ============================================================
# auth_operating_point.py
#
# Reproduces the authentication operating point and the
# re-enrollment bound quoted for the NLFSR-Shield protocol
# (Section 3.5.1 of the paper). It is pure statistics and
# arithmetic: no device model, no secrets, no search. A reader
# can regenerate the false-accept / false-reject figures and the
# lcm re-enrollment bound in one run.
#
#   FAR = P(impostor accepted) = P(Binom(m, 1/2)  <= tau)
#         (a random responder matches each compared bit w.p. 1/2)
#   FRR = P(legit rejected)    = P(Binom(m, 0.02) >  tau)
#         (a legitimate device differs on ~2% of bits after
#          k-fold temporal majority voting, k = 11)
#   tau = Hamming-distance acceptance threshold (accept iff
#         the number of mismatched bits is <= tau).
#
#   Re-enrollment bound = lcm(challenge-LFSR period 65535,
#                             device NLFSR period P_d).
# The verifier must re-enroll before its high-water mark reaches
# this joint period (Table I lists P_d for the adopted seeds).
#
#     python experiments/auth_operating_point.py
# Output: experiments/auth_operating_point_results.json
# ============================================================
import os, json
from math import comb, gcd, log2

HERE = os.path.dirname(os.path.abspath(__file__))


def binom_cdf_le(m, p, t):
    """Exact P(X <= t) for X ~ Binomial(m, p)."""
    return sum(comb(m, k) * p**k * (1.0 - p)**(m - k) for k in range(t + 1))


def far(m, tau):
    return binom_cdf_le(m, 0.5, tau)


def frr(m, tau, noise=0.02):
    return 1.0 - binom_cdf_le(m, noise, tau)


# Challenge-LFSR period and the NLFSR periods of the adopted device seeds
# (verification/nlfsr_period_seeds.c; also experiments/device_periods.txt).
LFSR_PERIOD = 65535
DEVICE_PERIODS = {
    0: 2876038240, 1: 2876038240, 2: 2876038240, 3: 2876038240,
    4: 611995400, 5: 2876038240, 6: 43712422, 7: 18659384,
    8: 611995400, 9: 2876038240,
}

res = {"m": 256, "noise": 0.02, "operating_points": [], "reenrollment": {}}

m = 256
print("Authentication operating point, m = %d bits per session, 2%% intra-device noise" % m)
print("%-5s %-8s %-24s %-24s" % ("tau", "tau/m", "FAR", "FRR"))
for tau in [20, 23, 26, 30, 38, 51, 64, 77]:
    a, r = far(m, tau), frr(m, tau)
    res["operating_points"].append({"tau": tau, "tau_over_m": tau / m, "FAR": a, "FRR": r})
    ab = ("2^%.1f" % log2(a)) if a > 0 else "0"
    rb = ("2^%.1f" % log2(r)) if r > 0 else "0"
    print("%-5d %-8.3f %-24s %-24s" % (tau, tau / m, "%.3e (%s)" % (a, ab), "%.3e (%s)" % (r, rb)))

tau = round(0.1 * m)                     # the adopted threshold, tau = 0.1 m
a, r = far(m, tau), frr(m, tau)
res["adopted"] = {"tau": tau, "tau_over_m": tau / m, "FAR": a, "FRR": r,
                  "FAR_log2": log2(a), "FRR_log2": log2(r)}
print("\nAdopted threshold tau = 0.1*m = %d:  FAR = 2^%.1f,  FRR = 2^%.1f" % (tau, log2(a), log2(r)))
print("Paper states conservative bounds FAR < 2^-130 and FRR < 2^-30.")

print("\nRe-enrollment bound  lcm(%d, P_d):" % LFSR_PERIOD)
for d, P in sorted(DEVICE_PERIODS.items()):
    L = LFSR_PERIOD * P // gcd(LFSR_PERIOD, P)
    res["reenrollment"]["device_%d" % d] = {"device_period": P, "joint_period": L, "log2": log2(L)}
    print("  device %d: P = %-12d lcm = %-15d (2^%.1f sessions)" % (d, P, L, log2(L)))
worst = min(DEVICE_PERIODS.values())
Lw = LFSR_PERIOD * worst // gcd(LFSR_PERIOD, worst)
res["reenrollment"]["worst_case"] = {"shortest_period": worst, "joint_period": Lw, "log2": log2(Lw)}
print("  worst case (shortest period %d): re-enroll before %d sessions (2^%.1f)" % (worst, Lw, log2(Lw)))

with open(os.path.join(HERE, "auth_operating_point_results.json"), "w") as f:
    json.dump(res, f, indent=1)
print("\nwrote auth_operating_point_results.json")
